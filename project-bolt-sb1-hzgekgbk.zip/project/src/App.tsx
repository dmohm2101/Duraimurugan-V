import React, { useState, useEffect } from 'react';
import LandingPage from './components/LandingPage';
import Auth from './components/Auth';
import RetailerDashboard from './components/RetailerDashboard';
import CustomerDashboard from './components/CustomerDashboard';
import ReviewerDashboard from './components/ReviewerDashboard';
import CurrentTrends from './components/CurrentTrends';
import Cart from './components/Cart';
import Header from './components/common/Header';
import LoadingSpinner from './components/common/LoadingSpinner';
import { useAuth } from './hooks/useAuth';
import { CartItem } from './utils/types';
import { storage, initializeSampleData } from './utils/storage';

type AppView = 'landing' | 'auth' | 'dashboard' | 'trends';

function App() {
  const { user, isAuthenticated, loading, login, logout } = useAuth();
  const [currentView, setCurrentView] = useState<AppView>('landing');
  const [showTrends, setShowTrends] = useState(false);
  const [showCart, setShowCart] = useState(false);
  const [cart, setCart] = useState<CartItem[]>([]);

  useEffect(() => {
    // Initialize sample data on first load
    initializeSampleData();
    
    // Load cart from storage
    const savedCart = storage.getCart();
    setCart(savedCart);
    
    // Auto-navigate to dashboard if user is logged in
    if (isAuthenticated && currentView !== 'dashboard') {
      setCurrentView('dashboard');
    }
  }, [isAuthenticated, currentView]);

  useEffect(() => {
    // Save cart to storage whenever it changes
    storage.setCart(cart);
  }, [cart]);

  const handleGetStarted = () => {
    setCurrentView('auth');
  };

  const handleAuth = (userData: any) => {
    login(userData);
    setCurrentView('dashboard');
  };

  const handleLogout = () => {
    logout();
    setCart([]);
    setCurrentView('landing');
  };

  const handleShowTrends = () => {
    setShowTrends(true);
  };

  const handleCloseTrends = () => {
    setShowTrends(false);
  };

  const handleShowCart = () => {
    setShowCart(true);
  };

  const handleCloseCart = () => {
    setShowCart(false);
  };

  const handleUpdateCart = (newCart: CartItem[]) => {
    setCart(newCart);
  };

  const getCartItemCount = () => {
    return cart.reduce((sum, item) => sum + item.quantity, 0);
  };

  if (loading) {
    return <LoadingSpinner />;
  }

  return (
    <div className="min-h-screen bg-gray-50">
      {isAuthenticated && currentView === 'dashboard' && (
        <Header 
          user={user}
          onLogout={handleLogout}
          onShowTrends={handleShowTrends}
          cartItemCount={getCartItemCount()}
          onShowCart={user?.role === 'customer' ? handleShowCart : undefined}
        />
      )}

      {currentView === 'landing' && (
        <LandingPage onGetStarted={handleGetStarted} />
      )}

      {currentView === 'auth' && (
        <Auth 
          onAuth={handleAuth}
          onBack={() => setCurrentView('landing')}
        />
      )}

      {currentView === 'dashboard' && user && (
        <>
          {user.role === 'retailer' && <RetailerDashboard user={user} />}
          {user.role === 'customer' && (
            <CustomerDashboard 
              user={user} 
              cart={cart}
              onUpdateCart={handleUpdateCart}
            />
          )}
          {user.role === 'reviewer' && <ReviewerDashboard user={user} />}
        </>
      )}

      {showTrends && (
        <CurrentTrends onClose={handleCloseTrends} />
      )}

      {showCart && user && (
        <Cart 
          cart={cart}
          onUpdateCart={handleUpdateCart}
          onClose={handleCloseCart}
          userId={user.id}
          userName={user.name}
        />
      )}
    </div>
  );
}

export default App;