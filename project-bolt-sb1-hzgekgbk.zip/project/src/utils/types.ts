export interface User {
  id: string;
  name: string;
  email: string;
  phone: string;
  role: 'retailer' | 'customer' | 'reviewer';
  district: string;
  address?: string;
  shopName?: string;
  picture?: string; // Added for Google profile picture
  createdAt: string;
}

export interface Product {
  id: string;
  name: string;
  description: string;
  price: number;
  category: string;
  image: string;
  retailerId: string;
  shopName: string;
  shopAddress: string;
  shopPhone: string;
  district: string;
  pincode: string;
  createdAt: string;
  tags: string[];
}

export interface Review {
  id: string;
  productId?: string;
  productName: string;
  reviewerId: string;
  reviewerName: string;
  type: 'personal' | 'retailer';
  rating: number;
  comment: string;
  pricePaid: number;
  shopName: string;
  shopAddress: string;
  district: string;
  image?: string;
  createdAt: string;
  verified: boolean;
}

export interface CartItem {
  productId: string;
  product: Product;
  quantity: number;
}

export interface Order {
  id: string;
  customerId: string;
  customerName: string;
  customerPhone: string;
  customerLocation: {
    lat: number;
    lng: number;
    address: string;
  };
  items: CartItem[];
  totalAmount: number;
  status: 'pending' | 'contacted' | 'completed';
  createdAt: string;
}

export interface TrendItem {
  id: string;
  name: string;
  category: string;
  type: 'trending' | 'rated' | 'value' | 'activity';
  score: number;
  district?: string;
  data: any;
}

export interface AuthState {
  isAuthenticated: boolean;
  user: User | null;
  loading: boolean;
}