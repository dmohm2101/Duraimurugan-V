import { Product, Review, TrendItem } from './types';
import { storage } from './storage';

export const generateTrends = (): TrendItem[] => {
  const products = storage.getProducts();
  const reviews = storage.getReviews();
  const orders = storage.getOrders();
  
  const trends: TrendItem[] = [];
  
  // Trending products (based on order frequency)
  const productOrderCount = orders.reduce((acc, order) => {
    order.items.forEach(item => {
      acc[item.productId] = (acc[item.productId] || 0) + item.quantity;
    });
    return acc;
  }, {} as Record<string, number>);
  
  const trendingProducts = products
    .map(product => ({
      ...product,
      orderCount: productOrderCount[product.id] || 0
    }))
    .sort((a, b) => b.orderCount - a.orderCount)
    .slice(0, 5);
    
  trendingProducts.forEach((product, index) => {
    trends.push({
      id: `trending-${product.id}`,
      name: product.name,
      category: product.category,
      type: 'trending',
      score: 100 - (index * 10),
      data: product
    });
  });
  
  // Highest rated products
  const productRatings = reviews.reduce((acc, review) => {
    if (review.productId) {
      if (!acc[review.productId]) {
        acc[review.productId] = { total: 0, count: 0 };
      }
      acc[review.productId].total += review.rating;
      acc[review.productId].count += 1;
    }
    return acc;
  }, {} as Record<string, { total: number; count: number }>);
  
  const highestRated = products
    .map(product => ({
      ...product,
      avgRating: productRatings[product.id] 
        ? productRatings[product.id].total / productRatings[product.id].count 
        : 0
    }))
    .filter(product => product.avgRating > 0)
    .sort((a, b) => b.avgRating - a.avgRating)
    .slice(0, 5);
    
  highestRated.forEach((product, index) => {
    trends.push({
      id: `rated-${product.id}`,
      name: product.name,
      category: product.category,
      type: 'rated',
      score: product.avgRating,
      data: product
    });
  });
  
  // Best value deals (price vs rating)
  const bestValue = products
    .map(product => {
      const rating = productRatings[product.id] 
        ? productRatings[product.id].total / productRatings[product.id].count 
        : 0;
      return {
        ...product,
        avgRating: rating,
        valueScore: rating > 0 ? (rating / product.price) * 100000 : 0
      };
    })
    .filter(product => product.avgRating > 0)
    .sort((a, b) => b.valueScore - a.valueScore)
    .slice(0, 5);
    
  bestValue.forEach((product, index) => {
    trends.push({
      id: `value-${product.id}`,
      name: product.name,
      category: product.category,
      type: 'value',
      score: product.valueScore,
      data: product
    });
  });
  
  return trends;
};

export const updateTrends = () => {
  const trends = generateTrends();
  storage.setTrends(trends);
  return trends;
};