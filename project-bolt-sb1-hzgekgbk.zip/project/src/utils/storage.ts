import { User, Product, Review, Order, TrendItem } from './types';

const STORAGE_KEYS = {
  USER: 'smartbuy_user',
  PRODUCTS: 'smartbuy_products',
  REVIEWS: 'smartbuy_reviews',
  ORDERS: 'smartbuy_orders',
  TRENDS: 'smartbuy_trends',
  CART: 'smartbuy_cart'
};

export const storage = {
  // User management
  setUser: (user: User) => {
    localStorage.setItem(STORAGE_KEYS.USER, JSON.stringify(user));
  },
  
  getUser: (): User | null => {
    const user = localStorage.getItem(STORAGE_KEYS.USER);
    return user ? JSON.parse(user) : null;
  },
  
  removeUser: () => {
    localStorage.removeItem(STORAGE_KEYS.USER);
  },
  
  // Products
  getProducts: (): Product[] => {
    const products = localStorage.getItem(STORAGE_KEYS.PRODUCTS);
    return products ? JSON.parse(products) : [];
  },
  
  setProducts: (products: Product[]) => {
    localStorage.setItem(STORAGE_KEYS.PRODUCTS, JSON.stringify(products));
  },
  
  addProduct: (product: Product) => {
    const products = storage.getProducts();
    products.push(product);
    storage.setProducts(products);
  },
  
  // Reviews
  getReviews: (): Review[] => {
    const reviews = localStorage.getItem(STORAGE_KEYS.REVIEWS);
    return reviews ? JSON.parse(reviews) : [];
  },
  
  setReviews: (reviews: Review[]) => {
    localStorage.setItem(STORAGE_KEYS.REVIEWS, JSON.stringify(reviews));
  },
  
  addReview: (review: Review) => {
    const reviews = storage.getReviews();
    reviews.push(review);
    storage.setReviews(reviews);
  },
  
  // Orders
  getOrders: (): Order[] => {
    const orders = localStorage.getItem(STORAGE_KEYS.ORDERS);
    return orders ? JSON.parse(orders) : [];
  },
  
  setOrders: (orders: Order[]) => {
    localStorage.setItem(STORAGE_KEYS.ORDERS, JSON.stringify(orders));
  },
  
  addOrder: (order: Order) => {
    const orders = storage.getOrders();
    orders.push(order);
    storage.setOrders(orders);
  },
  
  // Cart
  getCart: () => {
    const cart = localStorage.getItem(STORAGE_KEYS.CART);
    return cart ? JSON.parse(cart) : [];
  },
  
  setCart: (cart: any[]) => {
    localStorage.setItem(STORAGE_KEYS.CART, JSON.stringify(cart));
  },
  
  // Trends
  getTrends: (): TrendItem[] => {
    const trends = localStorage.getItem(STORAGE_KEYS.TRENDS);
    return trends ? JSON.parse(trends) : [];
  },
  
  setTrends: (trends: TrendItem[]) => {
    localStorage.setItem(STORAGE_KEYS.TRENDS, JSON.stringify(trends));
  }
};

// Initialize with sample data if empty
export const initializeSampleData = () => {
  if (storage.getProducts().length === 0) {
    const sampleProducts: Product[] = [
      {
        id: '1',
        name: 'Samsung Galaxy A54',
        description: 'Latest smartphone with 128GB storage',
        price: 35000,
        category: 'Electronics',
        image: 'https://images.pexels.com/photos/404280/pexels-photo-404280.jpeg',
        retailerId: 'retailer1',
        shopName: 'Tech World',
        shopAddress: '123 Anna Salai, Chennai',
        shopPhone: '+91 9876543210',
        district: 'Chennai',
        pincode: '600001',
        createdAt: new Date().toISOString(),
        tags: ['smartphone', 'samsung', 'android']
      },
      {
        id: '2',
        name: 'Cotton Saree',
        description: 'Traditional handwoven cotton saree',
        price: 2500,
        category: 'Clothing',
        image: 'https://images.pexels.com/photos/8142010/pexels-photo-8142010.jpeg',
        retailerId: 'retailer2',
        shopName: 'Silk Palace',
        shopAddress: '456 Pondy Bazaar, Chennai',
        shopPhone: '+91 9876543211',
        district: 'Chennai',
        pincode: '600017',
        createdAt: new Date().toISOString(),
        tags: ['saree', 'cotton', 'traditional']
      }
    ];
    storage.setProducts(sampleProducts);
  }
  
  if (storage.getReviews().length === 0) {
    const sampleReviews: Review[] = [
      {
        id: '1',
        productId: '1',
        productName: 'Samsung Galaxy A54',
        reviewerId: 'reviewer1',
        reviewerName: 'Priya Kumar',
        type: 'personal',
        rating: 4,
        comment: 'Great phone with excellent camera quality!',
        pricePaid: 34500,
        shopName: 'Tech World',
        shopAddress: '123 Anna Salai, Chennai',
        district: 'Chennai',
        createdAt: new Date().toISOString(),
        verified: true
      }
    ];
    storage.setReviews(sampleReviews);
  }
};