import React, { useState, useEffect } from 'react';
import { Star, Upload, Camera, MapPin, DollarSign, MessageCircle, Send, Eye, Award } from 'lucide-react';
import { Review, Product, User } from '../utils/types';
import { storage } from '../utils/storage';
import { tamilNaduDistricts, productCategories } from '../utils/districts';

interface ReviewerDashboardProps {
  user: User;
}

const ReviewerDashboard: React.FC<ReviewerDashboardProps> = ({ user }) => {
  const [products, setProducts] = useState<Product[]>([]);
  const [myReviews, setMyReviews] = useState<Review[]>([]);
  const [activeTab, setActiveTab] = useState<'write-review' | 'my-reviews' | 'explore'>('write-review');
  const [reviewType, setReviewType] = useState<'personal' | 'retailer'>('personal');
  const [showAddReview, setShowAddReview] = useState(false);
  const [selectedProduct, setSelectedProduct] = useState<Product | null>(null);
  const [newReview, setNewReview] = useState({
    productName: '',
    rating: 0,
    comment: '',
    pricePaid: '',
    shopName: '',
    shopAddress: '',
    district: '',
    image: ''
  });

  useEffect(() => {
    setProducts(storage.getProducts());
    const allReviews = storage.getReviews();
    const userReviews = allReviews.filter(review => review.reviewerId === user.id);
    setMyReviews(userReviews);
  }, [user.id]);

  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = (e) => {
        setNewReview(prev => ({
          ...prev,
          image: e.target?.result as string
        }));
      };
      reader.readAsDataURL(file);
    }
  };

  const handleRatingClick = (rating: number) => {
    setNewReview(prev => ({ ...prev, rating }));
  };

  const handleSubmitReview = (e: React.FormEvent) => {
    e.preventDefault();
    
    const review: Review = {
      id: Date.now().toString(),
      productId: selectedProduct?.id || undefined,
      productName: selectedProduct?.name || newReview.productName,
      reviewerId: user.id,
      reviewerName: user.name,
      type: reviewType,
      rating: newReview.rating,
      comment: newReview.comment,
      pricePaid: parseFloat(newReview.pricePaid),
      shopName: selectedProduct?.shopName || newReview.shopName,
      shopAddress: selectedProduct?.shopAddress || newReview.shopAddress,
      district: selectedProduct?.district || newReview.district,
      image: newReview.image,
      createdAt: new Date().toISOString(),
      verified: !!selectedProduct // Verified if based on retailer product
    };

    storage.addReview(review);
    setMyReviews(prev => [...prev, review]);
    
    // Reset form
    setNewReview({
      productName: '',
      rating: 0,
      comment: '',
      pricePaid: '',
      shopName: '',
      shopAddress: '',
      district: '',
      image: ''
    });
    setSelectedProduct(null);
    setShowAddReview(false);
    
    alert('Review submitted successfully! Thank you for contributing to SmartBuy community.');
  };

  const selectProductForReview = (product: Product) => {
    setSelectedProduct(product);
    setReviewType('retailer');
    setNewReview({
      productName: product.name,
      rating: 0,
      comment: '',
      pricePaid: product.price.toString(),
      shopName: product.shopName,
      shopAddress: product.shopAddress,
      district: product.district,
      image: ''
    });
    setShowAddReview(true);
  };

  const startPersonalReview = () => {
    setSelectedProduct(null);
    setReviewType('personal');
    setNewReview({
      productName: '',
      rating: 0,
      comment: '',
      pricePaid: '',
      shopName: '',
      shopAddress: '',
      district: '',
      image: ''
    });
    setShowAddReview(true);
  };

  const getReviewStats = () => {
    const personalReviews = myReviews.filter(r => r.type === 'personal');
    const retailerReviews = myReviews.filter(r => r.type === 'retailer');
    const avgRating = myReviews.length > 0 
      ? myReviews.reduce((sum, r) => sum + r.rating, 0) / myReviews.length 
      : 0;
    
    return {
      total: myReviews.length,
      personal: personalReviews.length,
      retailer: retailerReviews.length,
      avgRating
    };
  };

  const stats = getReviewStats();

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-50 to-pink-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-gray-900 mb-2">
            Welcome, {user.name}!
          </h1>
          <p className="text-gray-600">Share your honest reviews and help build a trusted marketplace</p>
          <div className="mt-4 flex items-center space-x-6">
            <div className="flex items-center">
              <MessageCircle className="w-5 h-5 text-purple-600 mr-2" />
              <span className="text-sm text-gray-600">{stats.total} Total Reviews</span>
            </div>
            <div className="flex items-center">
              <Star className="w-5 h-5 text-yellow-500 mr-2" />
              <span className="text-sm text-gray-600">{stats.avgRating.toFixed(1)} Avg Rating</span>
            </div>
            <div className="flex items-center">
              <Award className="w-5 h-5 text-blue-600 mr-2" />
              <span className="text-sm text-gray-600">Verified Contributor</span>
            </div>
          </div>
        </div>

        {/* Stats Cards */}
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
          <div className="bg-white rounded-xl p-4 shadow-lg text-center">
            <div className="text-2xl font-bold text-purple-600">{stats.total}</div>
            <div className="text-sm text-gray-600">Total Reviews</div>
          </div>
          <div className="bg-white rounded-xl p-4 shadow-lg text-center">
            <div className="text-2xl font-bold text-green-600">{stats.personal}</div>
            <div className="text-sm text-gray-600">🟢 Personal Use</div>
          </div>
          <div className="bg-white rounded-xl p-4 shadow-lg text-center">
            <div className="text-2xl font-bold text-blue-600">{stats.retailer}</div>
            <div className="text-sm text-gray-600">🔸 Retailer Product</div>
          </div>
          <div className="bg-white rounded-xl p-4 shadow-lg text-center">
            <div className="text-2xl font-bold text-orange-600">{stats.avgRating.toFixed(1)}</div>
            <div className="text-sm text-gray-600">Avg Rating</div>
          </div>
        </div>

        {/* Navigation Tabs */}
        <div className="flex space-x-1 bg-white rounded-lg p-1 mb-6 shadow-sm">
          <button
            onClick={() => setActiveTab('write-review')}
            className={`flex-1 py-3 px-4 rounded-lg font-medium transition-all duration-200 ${
              activeTab === 'write-review'
                ? 'bg-gradient-to-r from-purple-500 to-pink-500 text-white shadow-md'
                : 'text-gray-600 hover:text-gray-800'
            }`}
          >
            Write Review
          </button>
          <button
            onClick={() => setActiveTab('my-reviews')}
            className={`flex-1 py-3 px-4 rounded-lg font-medium transition-all duration-200 ${
              activeTab === 'my-reviews'
                ? 'bg-gradient-to-r from-purple-500 to-pink-500 text-white shadow-md'
                : 'text-gray-600 hover:text-gray-800'
            }`}
          >
            My Reviews
          </button>
          <button
            onClick={() => setActiveTab('explore')}
            className={`flex-1 py-3 px-4 rounded-lg font-medium transition-all duration-200 ${
              activeTab === 'explore'
                ? 'bg-gradient-to-r from-purple-500 to-pink-500 text-white shadow-md'
                : 'text-gray-600 hover:text-gray-800'
            }`}
          >
            Explore Products
          </button>
        </div>

        {activeTab === 'write-review' && (
          <div>
            <div className="bg-white rounded-xl shadow-lg p-8 mb-6">
              <h2 className="text-2xl font-bold text-gray-900 mb-6">Choose Review Type</h2>
              
              <div className="grid md:grid-cols-2 gap-6">
                {/* Personal Use Review */}
                <div className="border-2 border-green-200 rounded-xl p-6 bg-green-50 hover:border-green-300 transition-colors">
                  <div className="flex items-center mb-4">
                    <div className="w-12 h-12 bg-green-500 rounded-xl flex items-center justify-center mr-4">
                      <span className="text-white text-2xl">🟢</span>
                    </div>
                    <div>
                      <h3 className="text-xl font-bold text-gray-900">Personal Use Review</h3>
                      <p className="text-sm text-gray-600">Review products you've personally used</p>
                    </div>
                  </div>
                  <ul className="space-y-2 mb-6">
                    <li className="flex items-center text-sm text-gray-700">
                      <Star className="w-4 h-4 text-green-500 mr-2" />
                      Share your real experience
                    </li>
                    <li className="flex items-center text-sm text-gray-700">
                      <Camera className="w-4 h-4 text-green-500 mr-2" />
                      Upload your own photos
                    </li>
                    <li className="flex items-center text-sm text-gray-700">
                      <DollarSign className="w-4 h-4 text-green-500 mr-2" />
                      Help others with fair pricing
                    </li>
                  </ul>
                  <button
                    onClick={startPersonalReview}
                    className="w-full bg-green-500 text-white py-3 rounded-lg hover:bg-green-600 transition-colors"
                  >
                    Write Personal Review
                  </button>
                </div>

                {/* Retailer Product Review */}
                <div className="border-2 border-blue-200 rounded-xl p-6 bg-blue-50 hover:border-blue-300 transition-colors">
                  <div className="flex items-center mb-4">
                    <div className="w-12 h-12 bg-blue-500 rounded-xl flex items-center justify-center mr-4">
                      <span className="text-white text-2xl">🔸</span>
                    </div>
                    <div>
                      <h3 className="text-xl font-bold text-gray-900">Retailer Product Review</h3>
                      <p className="text-sm text-gray-600">Verify retailer listings</p>
                    </div>
                  </div>
                  <ul className="space-y-2 mb-6">
                    <li className="flex items-center text-sm text-gray-700">
                      <Award className="w-4 h-4 text-blue-500 mr-2" />
                      Verified review badge
                    </li>
                    <li className="flex items-center text-sm text-gray-700">
                      <Eye className="w-4 h-4 text-blue-500 mr-2" />
                      Help validate product quality
                    </li>
                    <li className="flex items-center text-sm text-gray-700">
                      <MessageCircle className="w-4 h-4 text-blue-500 mr-2" />
                      Build retailer trust
                    </li>
                  </ul>
                  <button
                    onClick={() => setActiveTab('explore')}
                    className="w-full bg-blue-500 text-white py-3 rounded-lg hover:bg-blue-600 transition-colors"
                  >
                    Browse Products to Review
                  </button>
                </div>
              </div>
            </div>
          </div>
        )}

        {activeTab === 'my-reviews' && (
          <div>
            <h2 className="text-2xl font-bold text-gray-900 mb-6">My Reviews</h2>
            
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {myReviews.map((review) => (
                <div key={review.id} className="bg-white rounded-xl shadow-lg p-6 hover:shadow-xl transition-shadow duration-200">
                  <div className="flex justify-between items-start mb-4">
                    <div>
                      <h3 className="font-bold text-gray-900">{review.productName}</h3>
                      <p className="text-sm text-gray-600">
                        {review.type === 'personal' ? '🟢 Personal Use' : '🔸 Retailer Product'}
                      </p>
                    </div>
                    <div className="flex items-center">
                      {[...Array(5)].map((_, i) => (
                        <Star
                          key={i}
                          className={`w-4 h-4 ${
                            i < review.rating ? 'text-yellow-500 fill-current' : 'text-gray-300'
                          }`}
                        />
                      ))}
                    </div>
                  </div>

                  {review.image && (
                    <img 
                      src={review.image} 
                      alt="Review"
                      className="w-full h-32 object-cover rounded-lg mb-4"
                    />
                  )}

                  <p className="text-gray-700 mb-4">"{review.comment}"</p>

                  <div className="border-t pt-4 space-y-2">
                    <div className="flex justify-between text-sm">
                      <span className="text-gray-600">Price Paid:</span>
                      <span className="font-semibold">₹{review.pricePaid.toLocaleString()}</span>
                    </div>
                    <div className="flex justify-between text-sm">
                      <span className="text-gray-600">Shop:</span>
                      <span className="font-semibold">{review.shopName}</span>
                    </div>
                    <div className="flex justify-between text-sm">
                      <span className="text-gray-600">District:</span>
                      <span className="font-semibold">{review.district}</span>
                    </div>
                    {review.verified && (
                      <div className="flex items-center text-green-600 text-sm">
                        <Award className="w-4 h-4 mr-1" />
                        Verified Review
                      </div>
                    )}
                  </div>

                  <div className="mt-4 text-xs text-gray-500">
                    {new Date(review.createdAt).toLocaleDateString()}
                  </div>
                </div>
              ))}
            </div>

            {myReviews.length === 0 && (
              <div className="text-center py-12">
                <MessageCircle className="w-16 h-16 text-gray-400 mx-auto mb-4" />
                <h3 className="text-xl font-semibold text-gray-900 mb-2">No reviews yet</h3>
                <p className="text-gray-600 mb-6">Start sharing your experiences to help the community</p>
                <button
                  onClick={() => setActiveTab('write-review')}
                  className="bg-gradient-to-r from-purple-500 to-pink-500 text-white px-6 py-3 rounded-lg hover:from-purple-600 hover:to-pink-600 transition-all duration-200"
                >
                  Write Your First Review
                </button>
              </div>
            )}
          </div>
        )}

        {activeTab === 'explore' && (
          <div>
            <h2 className="text-2xl font-bold text-gray-900 mb-6">Explore Products to Review</h2>
            
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {products.map((product) => (
                <div key={product.id} className="bg-white rounded-xl shadow-lg overflow-hidden hover:shadow-xl transition-shadow duration-200">
                  <div className="relative">
                    <img 
                      src={product.image} 
                      alt={product.name}
                      className="w-full h-48 object-cover"
                    />
                    <div className="absolute top-4 right-4 bg-white/90 rounded-full px-2 py-1 text-sm font-semibold">
                      ₹{product.price.toLocaleString()}
                    </div>
                  </div>
                  <div className="p-6">
                    <h3 className="text-xl font-bold text-gray-900 mb-2">{product.name}</h3>
                    <p className="text-gray-600 mb-3 line-clamp-2">{product.description}</p>
                    
                    <div className="flex items-center mb-3">
                      <MapPin className="w-4 h-4 text-gray-500 mr-2" />
                      <span className="text-sm text-gray-600">{product.shopName}, {product.district}</span>
                    </div>

                    <div className="flex items-center justify-between mb-4">
                      <span className="bg-purple-100 text-purple-800 text-sm px-2 py-1 rounded-full">
                        {product.category}
                      </span>
                      <div className="text-sm text-gray-500">
                        {new Date(product.createdAt).toLocaleDateString()}
                      </div>
                    </div>

                    <button
                      onClick={() => selectProductForReview(product)}
                      className="w-full bg-gradient-to-r from-blue-500 to-blue-600 text-white py-3 rounded-lg hover:from-blue-600 hover:to-blue-700 transition-all duration-200 flex items-center justify-center"
                    >
                      <Star className="w-4 h-4 mr-2" />
                      Review This Product
                    </button>
                  </div>
                </div>
              ))}
            </div>

            {products.length === 0 && (
              <div className="text-center py-12">
                <Eye className="w-16 h-16 text-gray-400 mx-auto mb-4" />
                <h3 className="text-xl font-semibold text-gray-900 mb-2">No products available</h3>
                <p className="text-gray-600">Products from retailers will appear here for you to review</p>
              </div>
            )}
          </div>
        )}

        {/* Add Review Modal */}
        {showAddReview && (
          <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
            <div className="bg-white rounded-2xl max-w-2xl w-full max-h-[90vh] overflow-y-auto">
              <div className="p-6">
                <div className="flex justify-between items-center mb-6">
                  <div>
                    <h2 className="text-2xl font-bold text-gray-900">
                      {reviewType === 'personal' ? '🟢 Personal Use Review' : '🔸 Retailer Product Review'}
                    </h2>
                    {selectedProduct && (
                      <p className="text-gray-600">Reviewing: {selectedProduct.name}</p>
                    )}
                  </div>
                  <button
                    onClick={() => setShowAddReview(false)}
                    className="text-gray-500 hover:text-gray-700"
                  >
                    ✕
                  </button>
                </div>

                <form onSubmit={handleSubmitReview} className="space-y-6">
                  {!selectedProduct && (
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-2">
                        Product Name
                      </label>
                      <input
                        type="text"
                        required
                        value={newReview.productName}
                        onChange={(e) => setNewReview(prev => ({...prev, productName: e.target.value}))}
                        className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-transparent"
                        placeholder="Enter product name"
                      />
                    </div>
                  )}

                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      Rating
                    </label>
                    <div className="flex items-center space-x-1">
                      {[1, 2, 3, 4, 5].map((rating) => (
                        <button
                          key={rating}
                          type="button"
                          onClick={() => handleRatingClick(rating)}
                          className="focus:outline-none"
                        >
                          <Star
                            className={`w-8 h-8 ${
                              rating <= newReview.rating 
                                ? 'text-yellow-500 fill-current' 
                                : 'text-gray-300 hover:text-yellow-400'
                            } transition-colors`}
                          />
                        </button>
                      ))}
                      <span className="ml-2 text-sm text-gray-600">
                        {newReview.rating > 0 ? `${newReview.rating}/5` : 'Click to rate'}
                      </span>
                    </div>
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      Your Review
                    </label>
                    <textarea
                      required
                      value={newReview.comment}
                      onChange={(e) => setNewReview(prev => ({...prev, comment: e.target.value}))}
                      className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-transparent"
                      rows={4}
                      placeholder="Share your honest experience with this product..."
                    />
                  </div>

                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-2">
                        Price Paid (₹)
                      </label>
                      <input
                        type="number"
                        required
                        value={newReview.pricePaid}
                        onChange={(e) => setNewReview(prev => ({...prev, pricePaid: e.target.value}))}
                        className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-transparent"
                        placeholder="0"
                        disabled={!!selectedProduct}
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-2">
                        District
                      </label>
                      <select
                        required
                        value={newReview.district}
                        onChange={(e) => setNewReview(prev => ({...prev, district: e.target.value}))}
                        className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-transparent"
                        disabled={!!selectedProduct}
                      >
                        <option value="">Select District</option>
                        {tamilNaduDistricts.map(district => (
                          <option key={district} value={district}>{district}</option>
                        ))}
                      </select>
                    </div>
                  </div>

                  {!selectedProduct && (
                    <>
                      <div>
                        <label className="block text-sm font-medium text-gray-700 mb-2">
                          Shop Name
                        </label>
                        <input
                          type="text"
                          required
                          value={newReview.shopName}
                          onChange={(e) => setNewReview(prev => ({...prev, shopName: e.target.value}))}
                          className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-transparent"
                          placeholder="Where did you buy this?"
                        />
                      </div>

                      <div>
                        <label className="block text-sm font-medium text-gray-700 mb-2">
                          Shop Address
                        </label>
                        <input
                          type="text"
                          required
                          value={newReview.shopAddress}
                          onChange={(e) => setNewReview(prev => ({...prev, shopAddress: e.target.value}))}
                          className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-transparent"
                          placeholder="Shop address or location"
                        />
                      </div>
                    </>
                  )}

                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      Product Photo (Optional)
                    </label>
                    <div className="flex items-center space-x-4">
                      <input
                        type="file"
                        accept="image/*"
                        onChange={handleImageUpload}
                        className="hidden"
                        id="review-image-upload"
                      />
                      <label
                        htmlFor="review-image-upload"
                        className="flex items-center px-4 py-2 bg-gray-100 border border-gray-300 rounded-lg cursor-pointer hover:bg-gray-200 transition-colors"
                      >
                        <Upload className="w-5 h-5 mr-2 text-gray-600" />
                        Upload Photo
                      </label>
                      {newReview.image && (
                        <img 
                          src={newReview.image} 
                          alt="Review preview"
                          className="w-16 h-16 object-cover rounded-lg"
                        />
                      )}
                    </div>
                  </div>

                  <div className="flex space-x-4">
                    <button
                      type="button"
                      onClick={() => setShowAddReview(false)}
                      className="flex-1 px-6 py-3 border border-gray-300 text-gray-700 rounded-lg hover:bg-gray-50 transition-colors"
                    >
                      Cancel
                    </button>
                    <button
                      type="submit"
                      disabled={newReview.rating === 0}
                      className="flex-1 px-6 py-3 bg-gradient-to-r from-purple-500 to-pink-500 text-white rounded-lg hover:from-purple-600 hover:to-pink-600 transition-all duration-200 disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center"
                    >
                      <Send className="w-5 h-5 mr-2" />
                      Submit Review
                    </button>
                  </div>
                </form>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default ReviewerDashboard;