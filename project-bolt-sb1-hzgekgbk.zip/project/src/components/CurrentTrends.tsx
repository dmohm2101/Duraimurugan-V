import React from 'react';
import { TrendingUp, Star, DollarSign, Activity, X } from 'lucide-react';
import { TrendItem } from '../utils/types';
import { updateTrends } from '../utils/trendGenerator';

interface CurrentTrendsProps {
  onClose: () => void;
}

const CurrentTrends: React.FC<CurrentTrendsProps> = ({ onClose }) => {
  const trends = updateTrends();
  
  const trendingItems = trends.filter(t => t.type === 'trending');
  const ratedItems = trends.filter(t => t.type === 'rated');
  const valueItems = trends.filter(t => t.type === 'value');

  const getTrendIcon = (type: string) => {
    switch (type) {
      case 'trending': return <TrendingUp className="w-5 h-5" />;
      case 'rated': return <Star className="w-5 h-5" />;
      case 'value': return <DollarSign className="w-5 h-5" />;
      default: return <Activity className="w-5 h-5" />;
    }
  };

  const getTrendColor = (type: string) => {
    switch (type) {
      case 'trending': return 'from-red-500 to-orange-500';
      case 'rated': return 'from-yellow-500 to-orange-500';
      case 'value': return 'from-green-500 to-emerald-500';
      default: return 'from-blue-500 to-purple-500';
    }
  };

  const TrendSection = ({ title, items, type }: { title: string; items: TrendItem[]; type: string }) => (
    <div className="bg-white rounded-xl shadow-lg p-6">
      <div className="flex items-center mb-4">
        <div className={`w-10 h-10 bg-gradient-to-r ${getTrendColor(type)} rounded-lg flex items-center justify-center mr-3`}>
          {getTrendIcon(type)}
        </div>
        <h3 className="text-xl font-bold text-gray-900">{title}</h3>
      </div>
      <div className="space-y-3">
        {items.slice(0, 5).map((item, index) => (
          <div key={item.id} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg hover:bg-gray-100 transition-colors">
            <div className="flex items-center">
              <span className="w-6 h-6 bg-gradient-to-r from-gray-600 to-gray-700 text-white rounded-full flex items-center justify-center text-sm font-bold mr-3">
                {index + 1}
              </span>
              <div>
                <h4 className="font-medium text-gray-900">{item.name}</h4>
                <p className="text-sm text-gray-500">{item.category}</p>
                {item.data.district && (
                  <p className="text-xs text-gray-400">{item.data.district}</p>
                )}
              </div>
            </div>
            <div className="text-right">
              {type === 'trending' && (
                <span className="text-sm font-semibold text-red-600">🔥 {Math.round(item.score)}%</span>
              )}
              {type === 'rated' && (
                <div className="flex items-center">
                  <Star className="w-4 h-4 text-yellow-500 fill-current mr-1" />
                  <span className="text-sm font-semibold text-gray-900">{item.score.toFixed(1)}</span>
                </div>
              )}
              {type === 'value' && (
                <span className="text-sm font-semibold text-green-600">💰 Value Pick</span>
              )}
              {item.data.price && (
                <p className="text-xs text-gray-500">₹{item.data.price.toLocaleString()}</p>
              )}
            </div>
          </div>
        ))}
      </div>
    </div>
  );

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
      <div className="bg-gradient-to-br from-orange-50 to-red-50 rounded-2xl max-w-6xl w-full max-h-[90vh] overflow-hidden">
        <div className="p-6 border-b border-gray-200 bg-white">
          <div className="flex items-center justify-between">
            <div className="flex items-center">
              <div className="w-12 h-12 bg-gradient-to-r from-orange-500 to-red-500 rounded-xl flex items-center justify-center mr-4">
                <TrendingUp className="w-6 h-6 text-white" />
              </div>
              <div>
                <h2 className="text-2xl font-bold text-gray-900">Current Market Trends</h2>
                <p className="text-gray-600">Real-time insights from Tamil Nadu's marketplace</p>
              </div>
            </div>
            <button
              onClick={onClose}
              className="p-2 hover:bg-gray-100 rounded-lg transition-colors"
            >
              <X className="w-6 h-6 text-gray-600" />
            </button>
          </div>
        </div>

        <div className="p-6 overflow-y-auto max-h-[calc(90vh-120px)]">
          {/* Live Stats */}
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
            <div className="bg-white rounded-xl p-4 text-center shadow-lg">
              <div className="text-2xl font-bold text-orange-600">2.5K+</div>
              <div className="text-sm text-gray-600">Total Reviews</div>
            </div>
            <div className="bg-white rounded-xl p-4 text-center shadow-lg">
              <div className="text-2xl font-bold text-blue-600">1K+</div>
              <div className="text-sm text-gray-600">Active Products</div>
            </div>
            <div className="bg-white rounded-xl p-4 text-center shadow-lg">
              <div className="text-2xl font-bold text-green-600">500+</div>
              <div className="text-sm text-gray-600">Retailers</div>
            </div>
            <div className="bg-white rounded-xl p-4 text-center shadow-lg">
              <div className="text-2xl font-bold text-purple-600">38</div>
              <div className="text-sm text-gray-600">Districts</div>
            </div>
          </div>

          {/* Trend Sections */}
          <div className="grid lg:grid-cols-3 gap-6">
            <TrendSection 
              title="🔥 Trending Now" 
              items={trendingItems} 
              type="trending" 
            />
            <TrendSection 
              title="⭐ Highest Rated" 
              items={ratedItems} 
              type="rated" 
            />
            <TrendSection 
              title="💰 Best Value Deals" 
              items={valueItems} 
              type="value" 
            />
          </div>

          {/* District Activity */}
          <div className="mt-8 bg-white rounded-xl shadow-lg p-6">
            <div className="flex items-center mb-4">
              <div className="w-10 h-10 bg-gradient-to-r from-blue-500 to-purple-500 rounded-lg flex items-center justify-center mr-3">
                <Activity className="w-5 h-5 text-white" />
              </div>
              <h3 className="text-xl font-bold text-gray-900">District Activity</h3>
            </div>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
              {['Chennai', 'Coimbatore', 'Madurai', 'Salem', 'Tiruchirappalli', 'Tirupur', 'Vellore', 'Erode'].map((district, index) => (
                <div key={district} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                  <span className="font-medium text-gray-900">{district}</span>
                  <div className="flex items-center">
                    <div className="w-2 h-2 bg-green-500 rounded-full mr-2"></div>
                    <span className="text-sm text-gray-600">{Math.floor(Math.random() * 50) + 10}</span>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default CurrentTrends;