import React, { useState, useEffect } from 'react';
import { Plus, Package, Star, Phone, MapPin, Upload, Eye, MessageCircle } from 'lucide-react';
import { Product, Review, Order, User } from '../utils/types';
import { storage } from '../utils/storage';
import { productCategories } from '../utils/districts';

interface RetailerDashboardProps {
  user: User;
}

const RetailerDashboard: React.FC<RetailerDashboardProps> = ({ user }) => {
  const [products, setProducts] = useState<Product[]>([]);
  const [reviews, setReviews] = useState<Review[]>([]);
  const [orders, setOrders] = useState<Order[]>([]);
  const [activeTab, setActiveTab] = useState<'products' | 'reviews' | 'orders'>('products');
  const [reviewTab, setReviewTab] = useState<'my-products' | 'similar'>('my-products');
  const [showAddProduct, setShowAddProduct] = useState(false);
  const [newProduct, setNewProduct] = useState({
    name: '',
    description: '',
    price: '',
    category: '',
    image: '',
    tags: ''
  });

  useEffect(() => {
    const allProducts = storage.getProducts();
    const myProducts = allProducts.filter(p => p.retailerId === user.id);
    setProducts(myProducts);
    
    const allReviews = storage.getReviews();
    setReviews(allReviews);
    
    const allOrders = storage.getOrders();
    const myOrders = allOrders.filter(order => 
      order.items.some(item => item.product.retailerId === user.id)
    );
    setOrders(myOrders);
  }, [user.id]);

  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = (e) => {
        setNewProduct(prev => ({
          ...prev,
          image: e.target?.result as string
        }));
      };
      reader.readAsDataURL(file);
    }
  };

  const handleAddProduct = (e: React.FormEvent) => {
    e.preventDefault();
    
    const product: Product = {
      id: Date.now().toString(),
      name: newProduct.name,
      description: newProduct.description,
      price: parseFloat(newProduct.price),
      category: newProduct.category,
      image: newProduct.image || 'https://images.pexels.com/photos/3785104/pexels-photo-3785104.jpeg',
      retailerId: user.id,
      shopName: user.shopName || 'My Shop',
      shopAddress: user.address || 'Address not provided',
      shopPhone: user.phone,
      district: user.district,
      pincode: '600001',
      createdAt: new Date().toISOString(),
      tags: newProduct.tags.split(',').map(tag => tag.trim()).filter(tag => tag)
    };

    storage.addProduct(product);
    setProducts(prev => [...prev, product]);
    setNewProduct({
      name: '',
      description: '',
      price: '',
      category: '',
      image: '',
      tags: ''
    });
    setShowAddProduct(false);
  };

  const getMyProductReviews = () => {
    const myProductIds = products.map(p => p.id);
    return reviews.filter(review => review.productId && myProductIds.includes(review.productId));
  };

  const getSimilarProductReviews = () => {
    const myCategories = [...new Set(products.map(p => p.category))];
    return reviews.filter(review => 
      !review.productId && myCategories.some(category => 
        review.productName.toLowerCase().includes(category.toLowerCase()) ||
        review.comment.toLowerCase().includes(category.toLowerCase())
      )
    );
  };

  const getAverageRating = () => {
    const myReviews = getMyProductReviews();
    if (myReviews.length === 0) return 0;
    
    const sum = myReviews.reduce((acc, review) => acc + review.rating, 0);
    return sum / myReviews.length;
  };

  const callCustomer = (phone: string) => {
    window.open(`tel:${phone}`, '_self');
  };

  const openMaps = (location: { lat: number; lng: number; address: string }) => {
    const url = `https://www.google.com/maps?q=${location.lat},${location.lng}`;
    window.open(url, '_blank');
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-purple-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-gray-900 mb-2">
            Welcome, {user.name}!
          </h1>
          <p className="text-gray-600">Manage your shop and connect with customers</p>
          <div className="mt-4 flex items-center space-x-6">
            <div className="flex items-center">
              <Package className="w-5 h-5 text-blue-600 mr-2" />
              <span className="text-sm text-gray-600">{products.length} Products</span>
            </div>
            <div className="flex items-center">
              <Star className="w-5 h-5 text-yellow-500 mr-2" />
              <span className="text-sm text-gray-600">{getAverageRating().toFixed(1)} Avg Rating</span>
            </div>
            <div className="flex items-center">
              <Phone className="w-5 h-5 text-green-600 mr-2" />
              <span className="text-sm text-gray-600">{orders.length} Orders</span>
            </div>
          </div>
        </div>

        {/* Navigation Tabs */}
        <div className="flex space-x-1 bg-white rounded-lg p-1 mb-6 shadow-sm">
          <button
            onClick={() => setActiveTab('products')}
            className={`flex-1 py-3 px-4 rounded-lg font-medium transition-all duration-200 ${
              activeTab === 'products'
                ? 'bg-gradient-to-r from-blue-500 to-purple-500 text-white shadow-md'
                : 'text-gray-600 hover:text-gray-800'
            }`}
          >
            My Products
          </button>
          <button
            onClick={() => setActiveTab('orders')}
            className={`flex-1 py-3 px-4 rounded-lg font-medium transition-all duration-200 ${
              activeTab === 'orders'
                ? 'bg-gradient-to-r from-blue-500 to-purple-500 text-white shadow-md'
                : 'text-gray-600 hover:text-gray-800'
            }`}
          >
            Customer Orders
          </button>
          <button
            onClick={() => setActiveTab('reviews')}
            className={`flex-1 py-3 px-4 rounded-lg font-medium transition-all duration-200 ${
              activeTab === 'reviews'
                ? 'bg-gradient-to-r from-blue-500 to-purple-500 text-white shadow-md'
                : 'text-gray-600 hover:text-gray-800'
            }`}
          >
            Reviews & Feedback
          </button>
        </div>

        {activeTab === 'products' && (
          <div>
            <div className="flex justify-between items-center mb-6">
              <h2 className="text-2xl font-bold text-gray-900">Product Inventory</h2>
              <button
                onClick={() => setShowAddProduct(true)}
                className="bg-gradient-to-r from-blue-500 to-purple-500 text-white px-6 py-3 rounded-lg hover:from-blue-600 hover:to-purple-600 transition-all duration-200 flex items-center"
              >
                <Plus className="w-5 h-5 mr-2" />
                Add Product
              </button>
            </div>

            {/* Products Grid */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {products.map((product) => {
                const productReviews = reviews.filter(r => r.productId === product.id);
                const avgRating = productReviews.length > 0 
                  ? productReviews.reduce((sum, r) => sum + r.rating, 0) / productReviews.length 
                  : 0;

                return (
                  <div key={product.id} className="bg-white rounded-xl shadow-lg overflow-hidden hover:shadow-xl transition-shadow duration-200">
                    <div className="relative">
                      <img 
                        src={product.image} 
                        alt={product.name}
                        className="w-full h-48 object-cover"
                      />
                      <div className="absolute top-4 right-4 bg-white/90 rounded-full px-2 py-1 text-sm font-semibold">
                        ₹{product.price.toLocaleString()}
                      </div>
                    </div>
                    <div className="p-6">
                      <h3 className="text-xl font-bold text-gray-900 mb-2">{product.name}</h3>
                      <p className="text-gray-600 mb-3 line-clamp-2">{product.description}</p>
                      
                      <div className="flex items-center justify-between mb-4">
                        <span className="bg-blue-100 text-blue-800 text-sm px-2 py-1 rounded-full">
                          {product.category}
                        </span>
                        {avgRating > 0 && (
                          <div className="flex items-center">
                            <Star className="w-4 h-4 text-yellow-500 fill-current mr-1" />
                            <span className="text-sm text-gray-600">
                              {avgRating.toFixed(1)} ({productReviews.length})
                            </span>
                          </div>
                        )}
                      </div>

                      <div className="text-sm text-gray-500 mb-4">
                        Added {new Date(product.createdAt).toLocaleDateString()}
                      </div>

                      <div className="flex items-center justify-between">
                        <div className="flex items-center text-sm text-gray-600">
                          <Eye className="w-4 h-4 mr-1" />
                          <span>Active</span>
                        </div>
                        <div className="flex items-center text-sm text-gray-600">
                          <MessageCircle className="w-4 h-4 mr-1" />
                          <span>{productReviews.length} reviews</span>
                        </div>
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>

            {products.length === 0 && (
              <div className="text-center py-12">
                <Package className="w-16 h-16 text-gray-400 mx-auto mb-4" />
                <h3 className="text-xl font-semibold text-gray-900 mb-2">No products yet</h3>
                <p className="text-gray-600 mb-6">Start by adding your first product to reach customers</p>
                <button
                  onClick={() => setShowAddProduct(true)}
                  className="bg-gradient-to-r from-blue-500 to-purple-500 text-white px-6 py-3 rounded-lg hover:from-blue-600 hover:to-purple-600 transition-all duration-200"
                >
                  Add Your First Product
                </button>
              </div>
            )}
          </div>
        )}

        {activeTab === 'orders' && (
          <div>
            <h2 className="text-2xl font-bold text-gray-900 mb-6">Customer Orders</h2>
            
            <div className="space-y-4">
              {orders.map((order) => (
                <div key={order.id} className="bg-white rounded-xl shadow-lg p-6">
                  <div className="flex justify-between items-start mb-4">
                    <div>
                      <h3 className="text-lg font-semibold text-gray-900">{order.customerName}</h3>
                      <p className="text-sm text-gray-600">Order #{order.id}</p>
                      <p className="text-sm text-gray-500">
                        {new Date(order.createdAt).toLocaleDateString()} at {new Date(order.createdAt).toLocaleTimeString()}
                      </p>
                    </div>
                    <div className="text-right">
                      <div className="text-xl font-bold text-green-600">
                        ₹{order.totalAmount.toLocaleString()}
                      </div>
                      <span className={`inline-block px-2 py-1 rounded-full text-xs font-medium ${
                        order.status === 'pending' ? 'bg-yellow-100 text-yellow-800' :
                        order.status === 'contacted' ? 'bg-blue-100 text-blue-800' :
                        'bg-green-100 text-green-800'
                      }`}>
                        {order.status.charAt(0).toUpperCase() + order.status.slice(1)}
                      </span>
                    </div>
                  </div>

                  <div className="border-t pt-4 mb-4">
                    <h4 className="font-medium text-gray-900 mb-2">Items Ordered:</h4>
                    <div className="space-y-2">
                      {order.items.map((item) => (
                        <div key={item.productId} className="flex justify-between items-center">
                          <span className="text-gray-700">
                            {item.product.name} × {item.quantity}
                          </span>
                          <span className="font-medium">
                            ₹{(item.product.price * item.quantity).toLocaleString()}
                          </span>
                        </div>
                      ))}
                    </div>
                  </div>

                  <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between space-y-3 sm:space-y-0">
                    <div className="flex items-center space-x-4">
                      <button
                        onClick={() => callCustomer(order.customerPhone)}
                        className="flex items-center px-4 py-2 bg-green-500 text-white rounded-lg hover:bg-green-600 transition-colors"
                      >
                        <Phone className="w-4 h-4 mr-2" />
                        Call Customer
                      </button>
                      <button
                        onClick={() => openMaps(order.customerLocation)}
                        className="flex items-center px-4 py-2 bg-blue-500 text-white rounded-lg hover:bg-blue-600 transition-colors"
                      >
                        <MapPin className="w-4 h-4 mr-2" />
                        View Location
                      </button>
                    </div>
                    <div className="text-sm text-gray-600">
                      <span className="font-medium">Phone:</span> {order.customerPhone}
                    </div>
                  </div>
                </div>
              ))}
            </div>

            {orders.length === 0 && (
              <div className="text-center py-12">
                <Phone className="w-16 h-16 text-gray-400 mx-auto mb-4" />
                <h3 className="text-xl font-semibold text-gray-900 mb-2">No orders yet</h3>
                <p className="text-gray-600">Customer orders will appear here when they show interest in your products</p>
              </div>
            )}
          </div>
        )}

        {activeTab === 'reviews' && (
          <div>
            <h2 className="text-2xl font-bold text-gray-900 mb-6">Reviews & Feedback</h2>
            
            {/* Review Type Tabs */}
            <div className="flex space-x-1 bg-white rounded-lg p-1 mb-6 shadow-sm">
              <button
                onClick={() => setReviewTab('my-products')}
                className={`flex-1 py-3 px-4 rounded-lg font-medium transition-all duration-200 ${
                  reviewTab === 'my-products'
                    ? 'bg-gradient-to-r from-green-500 to-blue-500 text-white shadow-md'
                    : 'text-gray-600 hover:text-gray-800'
                }`}
              >
                My Product Reviews
              </button>
              <button
                onClick={() => setReviewTab('similar')}
                className={`flex-1 py-3 px-4 rounded-lg font-medium transition-all duration-200 ${
                  reviewTab === 'similar'
                    ? 'bg-gradient-to-r from-green-500 to-blue-500 text-white shadow-md'
                    : 'text-gray-600 hover:text-gray-800'
                }`}
              >
                Feedback on Similar Goods
              </button>
            </div>

            {/* Reviews Display */}
            <div className="space-y-4">
              {(reviewTab === 'my-products' ? getMyProductReviews() : getSimilarProductReviews()).map((review) => (
                <div key={review.id} className="bg-white rounded-xl shadow-lg p-6">
                  <div className="flex justify-between items-start mb-4">
                    <div>
                      <h3 className="text-lg font-semibold text-gray-900">{review.productName}</h3>
                      <p className="text-sm text-gray-600">by {review.reviewerName}</p>
                    </div>
                    <div className="flex items-center">
                      {[...Array(5)].map((_, i) => (
                        <Star
                          key={i}
                          className={`w-5 h-5 ${
                            i < review.rating ? 'text-yellow-500 fill-current' : 'text-gray-300'
                          }`}
                        />
                      ))}
                    </div>
                  </div>

                  {review.image && (
                    <img 
                      src={review.image} 
                      alt="Review"
                      className="w-full h-40 object-cover rounded-lg mb-4"
                    />
                  )}

                  <p className="text-gray-700 mb-4 text-lg">"{review.comment}"</p>

                  <div className="grid grid-cols-2 md:grid-cols-4 gap-4 border-t pt-4">
                    <div>
                      <span className="text-sm text-gray-600">Price Paid:</span>
                      <p className="font-semibold">₹{review.pricePaid.toLocaleString()}</p>
                    </div>
                    <div>
                      <span className="text-sm text-gray-600">Shop:</span>
                      <p className="font-semibold">{review.shopName}</p>
                    </div>
                    <div>
                      <span className="text-sm text-gray-600">District:</span>
                      <p className="font-semibold">{review.district}</p>
                    </div>
                    <div>
                      <span className="text-sm text-gray-600">Type:</span>
                      <p className="font-semibold capitalize">
                        {review.type === 'personal' ? '🟢 Personal Use' : '🔸 Retailer Product'}
                      </p>
                    </div>
                  </div>

                  {review.verified && (
                    <div className="mt-4 flex items-center text-green-600">
                      <div className="w-3 h-3 bg-green-500 rounded-full mr-2"></div>
                      <span className="text-sm font-medium">Verified Review</span>
                    </div>
                  )}
                </div>
              ))}
            </div>

            {(reviewTab === 'my-products' ? getMyProductReviews() : getSimilarProductReviews()).length === 0 && (
              <div className="text-center py-12">
                <MessageCircle className="w-16 h-16 text-gray-400 mx-auto mb-4" />
                <h3 className="text-xl font-semibold text-gray-900 mb-2">
                  No {reviewTab === 'my-products' ? 'product reviews' : 'similar product feedback'} yet
                </h3>
                <p className="text-gray-600">
                  {reviewTab === 'my-products' 
                    ? 'Reviews for your products will appear here' 
                    : 'Feedback on similar products in your category will appear here'
                  }
                </p>
              </div>
            )}
          </div>
        )}

        {/* Add Product Modal */}
        {showAddProduct && (
          <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
            <div className="bg-white rounded-2xl max-w-2xl w-full max-h-[90vh] overflow-y-auto">
              <div className="p-6">
                <div className="flex justify-between items-center mb-6">
                  <h2 className="text-2xl font-bold text-gray-900">Add New Product</h2>
                  <button
                    onClick={() => setShowAddProduct(false)}
                    className="text-gray-500 hover:text-gray-700"
                  >
                    ✕
                  </button>
                </div>

                <form onSubmit={handleAddProduct} className="space-y-6">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      Product Name
                    </label>
                    <input
                      type="text"
                      required
                      value={newProduct.name}
                      onChange={(e) => setNewProduct(prev => ({...prev, name: e.target.value}))}
                      className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                      placeholder="Enter product name"
                    />
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      Description
                    </label>
                    <textarea
                      required
                      value={newProduct.description}
                      onChange={(e) => setNewProduct(prev => ({...prev, description: e.target.value}))}
                      className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                      rows={4}
                      placeholder="Describe your product"
                    />
                  </div>

                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-2">
                        Price (₹)
                      </label>
                      <input
                        type="number"
                        required
                        value={newProduct.price}
                        onChange={(e) => setNewProduct(prev => ({...prev, price: e.target.value}))}
                        className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                        placeholder="0"
                      />
                    </div>

                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-2">
                        Category
                      </label>
                      <select
                        required
                        value={newProduct.category}
                        onChange={(e) => setNewProduct(prev => ({...prev, category: e.target.value}))}
                        className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                      >
                        <option value="">Select Category</option>
                        {productCategories.map(category => (
                          <option key={category} value={category}>{category}</option>
                        ))}
                      </select>
                    </div>
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      Product Image
                    </label>
                    <div className="flex items-center space-x-4">
                      <input
                        type="file"
                        accept="image/*"
                        onChange={handleImageUpload}
                        className="hidden"
                        id="image-upload"
                      />
                      <label
                        htmlFor="image-upload"
                        className="flex items-center px-4 py-2 bg-gray-100 border border-gray-300 rounded-lg cursor-pointer hover:bg-gray-200 transition-colors"
                      >
                        <Upload className="w-5 h-5 mr-2 text-gray-600" />
                        Upload Image
                      </label>
                      {newProduct.image && (
                        <img 
                          src={newProduct.image} 
                          alt="Preview"
                          className="w-16 h-16 object-cover rounded-lg"
                        />
                      )}
                    </div>
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      Tags (comma separated)
                    </label>
                    <input
                      type="text"
                      value={newProduct.tags}
                      onChange={(e) => setNewProduct(prev => ({...prev, tags: e.target.value}))}
                      className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                      placeholder="e.g., new, trending, premium"
                    />
                  </div>

                  <div className="flex space-x-4">
                    <button
                      type="button"
                      onClick={() => setShowAddProduct(false)}
                      className="flex-1 px-6 py-3 border border-gray-300 text-gray-700 rounded-lg hover:bg-gray-50 transition-colors"
                    >
                      Cancel
                    </button>
                    <button
                      type="submit"
                      className="flex-1 px-6 py-3 bg-gradient-to-r from-blue-500 to-purple-500 text-white rounded-lg hover:from-blue-600 hover:to-purple-600 transition-all duration-200"
                    >
                      Add Product
                    </button>
                  </div>
                </form>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default RetailerDashboard;