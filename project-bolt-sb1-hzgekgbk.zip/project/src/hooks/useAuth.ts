import { useState, useEffect } from 'react';
import { User, AuthState } from '../utils/types';
import { storage } from '../utils/storage';

export const useAuth = () => {
  const [authState, setAuthState] = useState<AuthState>({
    isAuthenticated: false,
    user: null,
    loading: true
  });

  useEffect(() => {
    const user = storage.getUser();
    setAuthState({
      isAuthenticated: !!user,
      user,
      loading: false
    });
  }, []);

  const login = (user: User) => {
    storage.setUser(user);
    setAuthState({
      isAuthenticated: true,
      user,
      loading: false
    });
  };

  const logout = () => {
    storage.removeUser();
    setAuthState({
      isAuthenticated: false,
      user: null,
      loading: false
    });
  };

  const updateUser = (updatedUser: User) => {
    storage.setUser(updatedUser);
    setAuthState(prev => ({
      ...prev,
      user: updatedUser
    }));
  };

  return {
    ...authState,
    login,
    logout,
    updateUser
  };
};