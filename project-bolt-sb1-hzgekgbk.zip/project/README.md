# SmartBuy - Tamil Nadu's Smart Commerce Platform

A comprehensive e-commerce platform connecting Retailers, Customers, and Reviewers across Tamil Nadu with Google OAuth authentication.

## Features

### Authentication
- **Google OAuth Integration**: Sign in with Google account
- **Role-based Access**: Choose between Retailer, Customer, or Reviewer roles
- **Profile Completion**: Complete registration after Google sign-in

### User Roles

#### 🏪 Retailer
- Upload and manage products
- View customer orders with contact information
- Access reviews and feedback
- Track product performance

#### 🛒 Customer  
- Browse products by district and category
- Add items to cart and submit order interests
- View dual review system (Personal Use + Retailer Product reviews)
- Direct contact with retailers

#### ⭐ Reviewer
- Write Personal Use reviews
- Verify Retailer Product listings
- Upload review images
- Build community trust

## Google OAuth Setup

### 1. Create Google OAuth Credentials

1. Go to [Google Cloud Console](https://console.cloud.google.com/)
2. Create a new project or select existing one
3. Enable Google+ API and Google Identity Services
4. Go to "Credentials" → "Create Credentials" → "OAuth 2.0 Client IDs"
5. Configure OAuth consent screen
6. Add authorized JavaScript origins:
   - `http://localhost:5173` (for development)
   - `https://your-domain.com` (for production)

### 2. Environment Configuration

1. Copy `.env.example` to `.env`
2. Add your Google Client ID:
   ```
   VITE_GOOGLE_CLIENT_ID=your-google-client-id-here.apps.googleusercontent.com
   ```

### 3. Update Client ID in Code

In `src/components/Auth.tsx`, replace the placeholder with your actual Client ID:
```typescript
const GOOGLE_CLIENT_ID = 'your-actual-client-id-here.apps.googleusercontent.com';
```

## Installation & Setup

```bash
# Install dependencies
npm install

# Start development server
npm run dev

# Build for production
npm run build
```

## Technology Stack

- **Frontend**: React 18 + TypeScript
- **Styling**: Tailwind CSS
- **Icons**: Lucide React
- **Authentication**: Google OAuth 2.0
- **Storage**: LocalStorage (Firebase-ready)
- **Build Tool**: Vite

## Project Structure

```
src/
├── components/
│   ├── Auth.tsx                 # Google OAuth + Manual auth
│   ├── CustomerDashboard.tsx    # Customer interface
│   ├── RetailerDashboard.tsx    # Retailer interface
│   ├── ReviewerDashboard.tsx    # Reviewer interface
│   ├── Cart.tsx                 # Shopping cart
│   ├── CurrentTrends.tsx        # Market trends
│   └── common/
│       ├── Header.tsx           # App header with user info
│       └── LoadingSpinner.tsx   # Loading component
├── utils/
│   ├── googleAuth.ts           # Google OAuth service
│   ├── types.ts                # TypeScript interfaces
│   ├── storage.ts              # LocalStorage management
│   ├── districts.ts            # Tamil Nadu districts data
│   └── trendGenerator.ts       # AI-powered trends
└── hooks/
    └── useAuth.ts              # Authentication hook
```

## Key Features

### Google Authentication Flow
1. User clicks "Continue with Google"
2. Google OAuth popup/redirect
3. User data extracted from JWT token
4. Role selection for new users
5. Profile completion with additional details

### Security Features
- JWT token parsing and validation
- Secure credential handling
- Role-based access control
- User data encryption in storage

### User Experience
- Seamless Google sign-in
- Progressive profile completion
- Persistent authentication state
- Responsive design for all devices

## Deployment

The application is deployed on Netlify with automatic builds from the main branch.

### Environment Variables for Production
Set these in your Netlify dashboard:
- `VITE_GOOGLE_CLIENT_ID`: Your production Google OAuth Client ID

## Contributing

1. Fork the repository
2. Create a feature branch
3. Make your changes
4. Test Google OAuth integration
5. Submit a pull request

## License

MIT License - see LICENSE file for details

## Support

For issues related to Google OAuth setup or general questions, please create an issue in the repository.